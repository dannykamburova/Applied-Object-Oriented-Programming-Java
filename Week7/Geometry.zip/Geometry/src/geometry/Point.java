package geometry;

import java.util.Arrays;

public class Point {
    private double[] coords; // [x; y]

    public Point(double[] coords) {
        setCoords(coords);
    }

    public Point() {
        this(new double[2]);
    }

    public Point(Point point) {
        this(point.getCoords());
    }

    public double[] getCoords() {
        double[] copy = new double[coords.length];
        for (int i = 0; i<copy.length; i++){
            copy[i] = coords[i];
        }
        return coords;
    }

    public void setCoords(double[] coords) {
        if(coords != null && coords.length == 2) {
            this.coords = new double[coords.length];
            for(int i = 0; i < coords.length; i++) {
                this.coords[i] = coords[i];
                //validation coords[i]
            }
        }
        else{
            this.coords = new double[2]; //(0, 0)
        }
    }

    @Override
    public String toString() {
        return String.format("(%.2f; %.2f)",
                coords[0], coords[1]);
    }
}
